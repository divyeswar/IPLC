#include "symbtab.hh"
#include <iostream>
using namespace std;
void SymbTab::add_symbol(symbol_t* symb){
    this->Entries[symb->name]=symb;
    this->order.push_back(symb->name);
    
}
void SymbTab::print(){
    cout<<"[\n";
    for(auto entry=this->Entries.begin();entry!=this->Entries.end();++entry){
        cout<<"[";
        cout<<"\""<<entry->second->name<<"\""<<",";
        cout<<"\""<<entry->second->varfun<<"\""<<",";
        cout<<"\""<<entry->second->scope<<"\""<<",";
        cout<<entry->second->size<<",";
        // if(entry->second->offset==NULL){
        //     cout<<"\"-\",";
        // }
        // else{
        if(entry->second->varfun=="struct"){
            cout<<"\"-\""<<",";
        }
        else{
        cout<<entry->second->offset<<",";}
        cout<<"\""<<entry->second->dtype<<"\"";
        cout<<"]";
        if(next(entry)!=this->Entries.end()){
            cout<<",";
        }
        
    }
    cout<<"]";
}
void SymbTab::printgst(){
    this->print();
}
