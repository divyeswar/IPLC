#include "type.hh"
#include <iostream>
using namespace std;
void typecheck::insertval(string a)
{

   
    this->countstars = 0;
    this->countbraces = 0;
    int pos = a.find_first_of(' ');
    if (pos != -1)
    {
        this->datatype = a.substr(0, pos);
        a = a.substr(pos + 1, a.size());
        if (a.find_first_of('*') == -1 && a.find_first_of('[') == -1)
        {
            this->sname = a;
        }
        else
        {
            if (a.find_first_of('*') == -1)
            {
                pos = a.find_first_of('[');
                this->sname = a.substr(0, pos);
                while (pos != -1)
                {
                    
                    size_t endpos = a.find_first_of(']', pos);
                    this->countbraces++;
                    val.push_back(a.substr(pos + 1, endpos - pos - 1));
                    pos = a.find_first_of('[', endpos);
                }
            }
            else if (a.find_first_of('[') == -1)
            {
                pos = a.find_first_of('*');
                this->sname = a.substr(0, pos);
                while (pos != -1)
                {
                    
                    this->countstars = this->countstars + 1;
                    if (a[pos + 1] == '*')
                    {
                        this->countstars = this->countstars + 1;
                        pos++;
                    }
                    pos = a.find_first_of('*', pos + 1);
                }
            }
            else{
                pos = a.find_first_of('*');
                this->sname = a.substr(0, pos);
                while (pos != -1)
                {
                    
                    this->countstars = this->countstars + 1;
                    if (a[pos + 1] == '*')
                    {
                        this->countstars = this->countstars + 1;
                        pos++;
                    }
                    pos = a.find_first_of('*', pos + 1);
                }
                pos = a.find_first_of('[');
                while (pos != -1)
                {
                    
                    size_t endpos = a.find_first_of(']', pos);
                    this->countbraces++;
                    val.push_back(a.substr(pos + 1, endpos - pos - 1));
                    pos = a.find_first_of('[', endpos);
                }

            }
        }
    }
    else if (pos == -1)
    {
        if (a.find_first_of('*') == -1 && a.find_first_of('[') == -1)
        {
            this->datatype = a;
        }
        else
        {
            if (a.find_first_of('*') == -1)
            {
                pos = a.find_first_of('[');
                this->datatype = a.substr(0, pos);
                while (pos != -1)
                {
                    
                    size_t endpos = a.find_first_of(']', pos);
                    this->countbraces++;
                    val.push_back(a.substr(pos + 1, endpos - pos - 1));
                    pos = a.find_first_of('[', endpos);
                }
            }
            else if (a.find_first_of('[') == -1)
            {
                pos = a.find_first_of('*');
                this->datatype = a.substr(0, pos);
                while (pos != -1)
                {
                    
                    this->countstars = this->countstars + 1;
                    if (a[pos + 1] == '*')
                    {
                        this->countstars = this->countstars + 1;
                        pos++;
                    }
                    pos = a.find_first_of('*', pos + 1);
                }
            }
            else{
                pos = a.find_first_of('*');
                this->datatype = a.substr(0, pos);
                while (pos != -1)
                {
                    
                    this->countstars = this->countstars + 1;
                    if (a[pos + 1] == '*')
                    {
                        this->countstars = this->countstars + 1;
                        pos++;
                    }
                    pos = a.find_first_of('*', pos + 1);
                }
                pos = a.find_first_of('[');
                while (pos != -1)
                {
                    
                    size_t endpos = a.find_first_of(']', pos);
                    this->countbraces++;
                    val.push_back(a.substr(pos + 1, endpos - pos - 1));
                    pos = a.find_first_of('[', endpos);
                }

            }
        }}
       

     
        
    }
    string typecheck::conc()
    {
        string ret = this->datatype;
        for (int i = 0; i < this->countstars; i++)
        {
            ret = ret + "*";
        }
        for (int i = 0; i < this->countbraces; i++)
        {
            ret = ret + "[" + val[i] + "]";
        }
        return ret;
    }