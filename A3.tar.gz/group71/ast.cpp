#include "ast.hh"
using namespace std;
void empty_astnode::print(int blanks){
    cout<<"\"empty\"";
    
}
void seq_astnode::print(int blanks){
    cout<<"\"seq\": [";
    long unsigned int c=0;
    for(auto it:this->li){
        c++;
        if(it->emp){
        it->print(0);
        }
        else{
        cout<<"{";
        it->print(0);
        cout<<"}";}
        if(c<this->li.size()){
            cout<<",";
        }
    }
    cout<<"]";
}
void assignS_astnode::print(int blanks){
    cout<<"\"assignS\": {";
    cout<<"\"left\": {";
    this->left->print(0);
    cout<<"},";
    cout<<"\"right\": {";
    this->right->print(0);
    cout<<"}";
    cout<<"}";
    
}
void return_expnode::print(int blanks){
    cout<<"\"return\": {";
    this->exp->print(0);
    cout<<"}";
}
void proccall_astnode::print(int blanks){
    cout<<"\"proccall\": {";
    cout<<"\"fname\": {";
    cout<<"\"identifier\": \""<<this->name<<"\"";
    cout<<"},";
    cout<<"\"params\": [";
    long unsigned int c=0;
    for(auto it:this->li){
        c++;
        cout<<"{";
        it->print(0);
        cout<<"}";
        if(c<this->li.size()){
            cout<<",";
        }
    }
    cout<<"]";
    cout<<"}";

}
void if_astnode::print(int blanks){
    cout<<"\"if\": {";
    cout<<"\"cond\": {";
    this->exp->print(0);
    cout<<"},";
    cout<<"\"then\": ";
    if(this->left->emp){
        this->left->print(0);
        }
        else{
        cout<<"{";
        this->left->print(0);
        cout<<"}";}
    cout<<",";
    if(this->right!=NULL){
    if(this->right->emp){
        cout<<"\"else\": ";
        this->right->print(0);
    }
    else{
    cout<<"\"else\": {";
    this->right->print(0);
    cout<<"}"; }
    }
    cout<<"}";

}
void while_astnode::print(int blanks){
    cout<<"\"while\": {";
    cout<<"\"cond\": {";
    this->exp->print(0);
    cout<<"},";
    cout<<"\"stmt\": ";
    if(st->emp){
        st->print(0);
        }
        else{
        cout<<"{";
        st->print(0);
        cout<<"}";}
    cout<<"}";
}

void for_astnode::print(int blanks){
    cout<<"\"for\": {";
    cout<<"\"init\": {";
    this->exp1->print(0);
    cout<<"},";
    cout<<"\"guard\": {";
    this->exp2->print(0);
    cout<<"},";
    cout<<"\"step\": {";
    this->exp3->print(0);
    cout<<"},";
    cout<<"\"body\": ";
    if(st->emp){
        st->print(0);
        }
        else{
        cout<<"{";
        st->print(0);
        cout<<"}";}
    cout<<"}";
}
void op_binary_astnode::print(int blanks){
    cout<<"\"op_binary\": {";
    cout<<"\"op\": \""<<this->name<<"\",";
    cout<<"\"left\": {";
    this->left->print(0);
    cout<<"},";
    cout<<"\"right\": {";
    this->right->print(0);
    cout<<"}";
    cout<<"}";
}
void op_unary_astnode::print(int blanks){
    cout<<"\"op_unary\": {";
    cout<<"\"op\": \""<<this->name<<"\",";
    cout<<"\"child\": {";
    this->exp->print(0);
    cout<<"}}";
}
void assignE_exp::print(int blanks){
    cout<<"\"assignE\": {";
    cout<<"\"left\": {";
    this->left->print(0);
    cout<<"},";
    cout<<"\"right\": {";
    this->right->print(0);
    cout<<"}";
    cout<<"}";
}
void funcall_astnode::print(int blanks){
    cout<<"\"funcall\": {";
    cout<<"\"fname\": {";
    cout<<"\"identifier\": \""<<this->name<<"\"";
    cout<<"},";
    cout<<"\"params\": [";
    long unsigned int c=0;
    for(auto it:this->li){
        c++;
        cout<<"{";
        it->print(0);
        cout<<"}";
        if(c<this->li.size()){
            cout<<",";
        }
    }
    cout<<"]";
    cout<<"}";

}
void floatconst_astnode::print(int blanks){
    cout<<"\"floatconst\":"<<this->val;
}
void intconst_astnode::print(int blanks){
    cout<<"\"intconst\":"<<this->val;
}
void string_astnode::print(int blanks){
    cout<<"\"stringconst\":"<<this->name;
}
void identifier_astnode::print(int blanks){
    cout<<"\"identifier\":\""<<this->name<<"\"";
}

void arrow_astnode::print(int blanks){
    cout<<"\"arrow\": {";
    cout<<"\"pointer\": {";
    this->exp->print(0);
    cout<<"},";
    cout<<"\"field\": {";
    this->id->print(0);
    cout<<"}";
    cout<<"}";
}
void member_astnode::print(int blanks){
    cout<<"\"member\": {";
    cout<<"\"struct\": {";
    this->exp->print(0);
    cout<<"},";
    cout<<"\"field\": {";
    this->id->print(0);
    cout<<"}";
    cout<<"}";
}
void arrayref_astnode::print(int blanks){
    cout<<"\"arrayref\": {";
    cout<<"\"array\": {";
    this->left->print(0);
    cout<<"},";
    cout<<"\"index\": {";
    this->right->print(0);
    cout<<"}";
    cout<<"}";
}


