#include <string>
#include <vector>
#include <iostream>
#include <cstdlib>
#include "type.hh"
using std::string;
using std::vector;

class abstract_astnode
{
public:
    virtual void print(int blanks) = 0;
};
//cal=0(default),1(add),2(sub),3(mul),4(div),5(lt),6(gt),7(lte),8(gte),9(assign)
class exp_astnode : public abstract_astnode
{
public:
    exp_astnode *left;
    exp_astnode *right;
    vector<exp_astnode *> li;
    typecheck typ;
    int cal = 0;
    int jmp = 2;
    int fcalls = 0;
    int label = -1;
    bool infun = 0;
    string fun;
    string loc = "";
    int off = 0;
};
class statement_astnode : public abstract_astnode
{
public:
    bool emp;
    statement_astnode()
    {
        this->emp = 0;
    }
};
class ref_astnode : public exp_astnode
{
};
class empty_astnode : public statement_astnode
{
public:
    empty_astnode()
    {
        this->emp = 1;
    }
    void print(int blanks);
};
class seq_astnode : public statement_astnode
{
public:
    seq_astnode(){};
    seq_astnode(vector<statement_astnode *> li)
    {
        this->li = li;
    };
    void print(int blanks);
    vector<statement_astnode *> li;
};
class assignS_astnode : public statement_astnode
{
public:
    void print(int blanks);
    assignS_astnode(exp_astnode *left, exp_astnode *right)
    {
        this->left = left;
        this->right = right;
    };
    exp_astnode *left;
    exp_astnode *right;
};
class return_expnode : public statement_astnode
{
public:
    return_expnode(exp_astnode *exp)
    {
        this->exp = exp;
    };
    void print(int blanks);
    exp_astnode *exp;
};

class proccall_astnode : public statement_astnode
{
public:
    void print(int blanks);
    proccall_astnode(string name)
    {
        this->name = name;
    };
    proccall_astnode(string name, vector<exp_astnode *> li)
    {
        this->name = name;
        this->li = li;
    };
    vector<exp_astnode *> li;
    string name;
};
class if_astnode : public statement_astnode
{
public:
    if_astnode(exp_astnode *exp, statement_astnode *left, statement_astnode *right)
    {
        this->exp = exp;
        this->left = left;
        this->right = right;
    };
    exp_astnode *exp;
    statement_astnode *left;
    statement_astnode *right;
    void print(int blanks);
};
class while_astnode : public statement_astnode
{
public:
    while_astnode(exp_astnode *exp, statement_astnode *st)
    {
        this->exp = exp;
        this->st = st;
    };
    exp_astnode *exp;
    statement_astnode *st;
    void print(int blanks);
};
class for_astnode : public statement_astnode
{
public:
    for_astnode(exp_astnode *exp1, exp_astnode *exp2, exp_astnode *exp3, statement_astnode *st)
    {
        this->exp1 = exp1;
        this->exp2 = exp2;
        this->exp3 = exp3;
        this->st = st;
    };
    exp_astnode *exp1;
    exp_astnode *exp2;
    exp_astnode *exp3;
    statement_astnode *st;
    void print(int blanks);
};
class op_binary_astnode : public exp_astnode
{
public:
    string name;
    // exp_astnode* left;
    // exp_astnode* right;
    op_binary_astnode(string name, exp_astnode *left, exp_astnode *right)
    {
        this->name = name;
        this->left = left;
        this->right = right;
    };
    void print(int blanks);
};
class op_unary_astnode : public exp_astnode
{
public:
    string name;
    exp_astnode *exp;
    op_unary_astnode(string name, exp_astnode *exp)
    {
        this->name = name;
        this->exp = exp;
    };
    void print(int blanks);
};
class assignE_exp : public exp_astnode
{
public:
    // exp_astnode* left;
    // exp_astnode* right;
    assignE_exp(exp_astnode *left, exp_astnode *right)
    {
        this->left = left;
        this->right = right;
    }
    void print(int blanks);
};
class funcall_astnode : public exp_astnode
{
public:
    string name;
    // vector<exp_astnode *> li;
    funcall_astnode(string name)
    {
        this->name = name;
    };
    funcall_astnode(string name, vector<exp_astnode *> li)
    {
        this->name = name;
        this->li = li;
    };
    void print(int blanks);
};
class floatconst_astnode : public exp_astnode
{
public:
    floatconst_astnode(string val)
    {
        this->val = std::atof(&val[0]);
    }
    float val;
    void print(int blanks);
};
class intconst_astnode : public exp_astnode
{
public:
    intconst_astnode(string val)
    {
        this->val = std::atoi(&val[0]);
    }
    int val;
    void print(int blanks);
};
class string_astnode : public exp_astnode
{
public:
    string name;
    string_astnode(string name)
    {
        this->name = name;
    }
    void print(int blanks);
};
class identifier_astnode : public ref_astnode
{
public:
    string name;
    identifier_astnode(string name)
    {
        this->name = name;
    };
    void print(int blanks);
};
class member_astnode : public ref_astnode
{
public:
    exp_astnode *exp;
    identifier_astnode *id;
    member_astnode(exp_astnode *exp, string name)
    {
        this->exp = exp;
        this->id = new identifier_astnode(name);
    }
    void print(int blanks);
};
class arrow_astnode : public ref_astnode
{
public:
    exp_astnode *exp;
    identifier_astnode *id;
    arrow_astnode(exp_astnode *exp, string name)
    {
        this->left = exp;
        this->exp = exp;
        this->id = new identifier_astnode(name);
        this->right = this->id;
    };
    void print(int blanks);
};

class arrayref_astnode : public ref_astnode
{
public:
    // exp_astnode* left;
    // exp_astnode* right;
    arrayref_astnode(exp_astnode *left, exp_astnode *right)
    {
        this->left = left;
        this->right = right;
    }
    void print(int blanks);
};