#include "codegen.hh"
using namespace std;
extern std::map<string, vector<string>> comp;
extern std::map<string, vector<pair<string, int>>> strval;
extern vector<string> reg, inst, funcord;
extern int val, top, strco, jmpco;
extern vector<int> mem;
extern vector<pair<string, int>> strings;
string arr[19] = {"movl", "addl", "subl", "imull", "idivl", "setl", "setg", "setle", "setge", "sete", "setne", "", "", "movl", "leal", "movl", "not", "post", "deref"};
string to_str(int a)
{
    bool neg;
    string s;
    if (a < 0)
    {
        neg = 1;
        a = a * -1;
    }
    while (a > 0)
    {
        char c = 48 + (a % 10);
        // cout<<c<<"vs"<<endl;
        s = c + s;
        // cout<<s<<"val"<<endl;
        a = a / 10;
    }
    if (neg)
    {
        s = "-" + s;
    }
    return s;
}
void swap()
{
    string s;
    s = reg[top + 1];
    reg[top + 1] = reg[top];
    reg[top] = s;
}

void codeg(exp_astnode *exp)
{
    // // cout<<"yes"<<endl;
    // cout << exp->label << endl;
    // cout << exp->cal << endl;
    // // // // cout << exp->off << endl;
    // cout << exp->left->label<<endl;
    // cout << exp->left->cal<<endl;
    // // // // // // // cout << exp->left->off;
    // // // // // cout << exp->left->loc << endl;
    // // // // // // cout << to_str(exp->left->off) << endl;
    // cout << exp->right->label<<endl;
    // cout << exp->right->cal<<endl;
    // // cout << exp->right->off << endl;
    // // cout << to_str(exp->right->off) << endl;

    // cout << top << reg[top] << endl;
    // cout << "cam" << endl;

    if (exp->infun)
    {
        // cout<<"came3"<<endl;
        mem.push_back(top);
        for (int i = 0; i < top; i++)
        {
            inst.push_back("    pushl   %" + reg[i]);
        }
        top = 0;
        for (vector<exp_astnode *>::iterator it = exp->li.begin(); it != exp->li.end(); ++it)
        {
            if ((*it)->typ.conc() == "int" ||(*it)->typ.conc() == "struct")
            {
            // cout<<(*it)->typ.conc()<<endl;

                codeg(*it);
                inst.push_back("    pushl   %" + reg[top - 1]);
            }
            else
            {
                // cout<<"came here"<<endl;
                if (exp->cal == 50)
                {
                    codeg(*it);
                    inst.push_back("    pushl   %" + reg[top - 2]);
                    top--;
                    
                }
                else
                {
                    // cout<<"came"<<endl;
                    inst.push_back("    leal    " + to_string((*it)->off) + "(%ebp), %" + reg[top]);
                    inst.push_back("    pushl   %" + reg[top]);
                    // cout<<"came out"<<endl;
                }
            }
            top = 0;
        }
    
    inst.push_back("    call    " + exp->fun);
    if (exp->off != 0)
        inst.push_back("    addl    $" + to_string(exp->off) + ", %esp");
    top = mem[mem.size() - 1];
    inst.push_back("    movl    %eax, %" + reg[top]);
    for (int i = top - 1; i >= 0; i--)
    {
        inst.push_back("    popl    " + reg[i]);
    }
    top = top + 1;
    mem.pop_back();
}

else
{
    if (exp->cal == 16)
    {
        // cout<<"came4"<<endl;
        codeg(exp->right);
        inst.push_back("    not %" + reg[top - 1]);
        return;
    }
    
    if (exp->cal == 50)
    {
        if (exp->left->cal == 0)
        {
            inst.push_back("    leal    " + to_string(exp->left->off) + "(%" + exp->left->loc + "), %" + reg[top]);
            top++;

            codeg(exp->right);
            inst.push_back("    imull   $" + to_string(exp->off) + ", %" + reg[top - 1]);
            inst.push_back("    addl    %" + reg[top - 1] + ", %" + reg[top - 2]);
            inst.push_back("    movl    (%" + reg[top - 2] + "), %" + reg[top - 1]);
        }
        else
        {
            codeg(exp->left);
            codeg(exp->right);
            inst.push_back("    imull   $" + to_string(exp->off) + ", %" + reg[top - 1]);
            inst.push_back("    addl    %" + reg[top - 1] + ", %" + reg[top - 3]);
            inst.push_back("    movl    (%" + reg[top - 3] + "), %" + reg[top - 2]);
            top--;
        }
        return;
    }
    if (exp->cal == 17)
    {
        // cout<<"came5"<<endl;
        codeg(exp->left);
        exp_astnode *a = new op_binary_astnode("PLUS_INT", exp->left, exp->right);
        a->cal = 1;
        if (exp->left->label == -1 && exp->right->label == -1)
        {
            a->label = 1;
        }
        else
        {
            if (exp->left->label == exp->right->label)
            {
                a->label = a->label + 1;
            }
            else
            {
                a->label = std::max(exp->left->label, exp->right->label);
            }
        }
        exp_astnode *b = new assignE_exp(exp->left, a);
        b->cal = 13;
        if (exp->left->label == -1 && a->label == -1)
        {
            b->label = 1;
        }
        else
        {
            if (exp->left->label == b->label)
            {
                b->label = exp->left->label + 1;
            }
            else
            {
                b->label = std::max(exp->left->label, b->label);
            }
        }
        codeg(b);

        return;
    }
    if (exp->cal == 13)
    {
        // cout<<"came10"<<endl;
        if (exp->left->cal == 0)
        {
            // cout<<"came"<<endl;
            // cout<<"e"<<exp->right->cal<<","<<exp->right->right->cal<<endl;
            codeg(exp->right);
            // cout<<"came2"<<endl;
            inst.push_back("    " + arr[exp->cal] + "  %" + reg[top - 1] + ", " + to_string(exp->left->off) + "(%" + exp->left->loc + ")");
            top--;
            return;
        }
        else if(exp->left->cal==15){
        codeg(exp->left->left);

        codeg(exp->right);
        if(exp->left->right->off!=0)
        inst.push_back("    movl    %"+reg[top-1]+", "+to_string(exp->left->right->off)+"(%"+reg[top-2]+")");
        else
        inst.push_back("    movl    %"+reg[top-1]+", (%"+reg[top-2]+")");
        return;}
        else if (exp->left->cal == 50)
        {
            codeg(exp->left);
            codeg(exp->right);
            inst.push_back("    movl    %" + reg[top - 1] + ", (%" + reg[top - 3] + ")");
            return;
        }
        else if (exp->left->cal == 18)
        {
            // cout<<"came6"<<endl;
            codeg(exp->left->right);
            codeg(exp->right);
            inst.push_back("    movl   %" + reg[top - 1] + ", (%" + reg[top - 2] + ")");
            top--;
            return;
        }
    }
    else
    {
        // {   cout<<"came8"<<endl;
        if (exp->cal == 18)
        {
            // cout<<"came7"<<endl;

            codeg(exp->right);
            inst.push_back("    movl    (%" + reg[top - 1] + "), %" + reg[top - 1]);
            return;
        }
        else if(exp->cal==15){
        codeg(exp->left);
        if(exp->right->off!=0)
        inst.push_back("    movl    "+to_string(exp->right->off)+"(%"+reg[top-1]+"), %"+reg[top-1]);
        else    inst.push_back("    movl    (%"+reg[top-1]+"), %"+reg[top-1]);
        return;}
    
        if (exp->label == -1)
        {
            // cout << "insidel left"<<exp->off << endl;

            if (exp->infun == 0)
            {
                if (exp->cal == 0)
                {
                    if (exp->loc != "")
                    {
                        inst.push_back("    " + arr[exp->cal] + "  " + to_string(exp->off) + "(%" + exp->loc + ")," + "%" + reg[top]);
                    }
                    else
                    {
                        inst.push_back("    " + arr[exp->cal] + "  $" + to_string(exp->off) + "," + "%" + reg[top]);
                    }
                }
                else
                {
                    inst.push_back("    " + arr[exp->cal] + "  " + to_string(exp->off) + "(%" + exp->loc + ")," + "%" + reg[top]);
                }
            }
            top++;
        }

        else if (exp->left->label >= 6 && exp->right->label >= 6)
        {
            codeg(exp->right);
            inst.push_back("    pushl   %" + reg[top - 1]);
            top--;
            val = val - 4;
            int val1 = val;
            val = val + 4;
            if (exp->cal == 11)
            {
                inst.push_back("    cmpl    $0, " + to_string(val1) + "(%ebp)");
                inst.push_back("    je .L" + to_string(jmpco));
                codeg(exp->left);
                inst.push_back("    cmpl    $0, " + reg[top - 1]);
                // jmpco++;
                inst.push_back("    je .L" + to_string(jmpco));
            }
            else if (exp->cal == 12)
            {
                inst.push_back("    cmpl    $0, " + to_string(val1) + "(%ebp)");
                inst.push_back("    jne .L" + to_string(jmpco));
                codeg(exp->left);
                inst.push_back("    cmpl    $0, " + reg[top - 1]);
                // jmpco++;
                inst.push_back("    jne .L" + to_string(jmpco));
            }
            else
            {
                codeg(exp->left);
            }

            if (exp->cal != 4)
            {
                if (exp->cal > 4 && exp->cal <= 10)
                {
                    inst.push_back("    cmpl    " + to_string(val1) + "(%ebp)," + "%" + reg[top - 1]);
                    inst.push_back("    " + arr[exp->cal] + "   %al");
                    inst.push_back("    movzbl  %al, %" + reg[top - 1]);
                }
                else if (exp->cal == 11)
                {
                    // inst.push_back(".L"+to_string(jmpco-1)+":");
                    inst.push_back("    movl    $1, %" + reg[top - 1]);
                    jmpco++;
                    inst.push_back("    jmp .L" + to_string(jmpco));
                    inst.push_back(".L" + to_string(jmpco - 1) + ":");
                    inst.push_back("    movl    $0, %" + reg[top - 1]);
                    inst.push_back(".L" + to_string(jmpco) + ":");
                    jmpco++;
                }
                else if (exp->cal == 12)
                {
                    // inst.push_back(".L"+to_string(jmpco-1)+":");
                    inst.push_back("    movl    $0, %" + reg[top - 1]);
                    jmpco++;
                    inst.push_back("    jmp .L" + to_string(jmpco));
                    inst.push_back(".L" + to_string(jmpco - 1) + ":");
                    inst.push_back("    movl    $1, %" + reg[top - 1]);
                    inst.push_back(".L" + to_string(jmpco) + ":");
                    jmpco++;
                }

                else
                    inst.push_back("    " + arr[exp->cal] + "   " + to_string(val1) + "(%ebp)," + "%" + reg[top - 1]);
            }
            else
            {

                inst.push_back("    pushl   %eax");
                // inst.push_back("    pushl   %" + reg[top + 1]);
                inst.push_back("    movl    " + to_string(val1) + "(%ebp), %" + reg[top]);
                inst.push_back("    addl    $4, %esp");
                inst.push_back("    movl    %" + reg[top - 1] + ", %eax");

                inst.push_back("    cltd");
                inst.push_back("    idivl   %" + reg[top]);
                inst.push_back("    movl    %eax, %" + reg[top - 1]);
                //inst.push_back("    movl    %" + reg[top + 1] + ", %" + reg[top + 2]);
                // inst.push_back("    popl   %" + reg[top + 1]);
                inst.push_back("    popl   %eax");
            }
            /*else
                {
                    inst.push_back("    movl    %" + reg[top] + ", %eax");
                    inst.push_back("    movl    " + to_string(val1) + "(%ebp), %" + reg[top + 1]);
                    inst.push_back("    cltd");
                    inst.push_back("    idivl   %" + reg[top + 1]);
                    inst.push_back("    movl    %eax, %" + reg[top]);
                    inst.push_back("    movl    %" + reg[top + 1] + ", %" + reg[top + 2]);
                }*/
        }

        else if (exp->right->label < 6 && (exp->left->label >= exp->right->label && exp->right->label != -1))
        {
            codeg(exp->left);
            if (exp->cal == 11)
            {
                inst.push_back("    cmpl    $0, %" + reg[top - 1]);
                inst.push_back("    je .L" + to_string(jmpco));
                codeg(exp->right);
                inst.push_back("    cmpl    $0, %" + reg[top - 1]);
                // jmpco++;
                inst.push_back("    je .L" + to_string(jmpco));
            }
            else if (exp->cal == 12)
            {
                inst.push_back("    cmpl    $0, %" + reg[top - 1]);
                inst.push_back("    jne .L" + to_string(jmpco));
                codeg(exp->right);
                inst.push_back("    cmpl    $0, %" + reg[top - 1]);
                // jmpco++;
                inst.push_back("    jne .L" + to_string(jmpco));
            }
            else
            {
                codeg(exp->right);
            }
            if (exp->cal != 4)
            {
                if (exp->cal > 4 && exp->cal <= 10)
                {
                    inst.push_back("    cmpl    %" + reg[top - 1] + ",%" + reg[top - 2]);
                    inst.push_back("    " + arr[exp->cal] + "   %al");
                    inst.push_back("    movzbl  %al, %" + reg[top - 2]);
                }
                else if (exp->cal == 11)
                {
                    // inst.push_back(".L"+to_string(jmpco-1)+":");
                    inst.push_back("    movl    $1, %" + reg[top - 2]);
                    jmpco++;
                    inst.push_back("    jmp .L" + to_string(jmpco));
                    inst.push_back(".L" + to_string(jmpco - 1) + ":");
                    inst.push_back("    movl    $0, %" + reg[top - 2]);
                    inst.push_back(".L" + to_string(jmpco) + ":");
                    jmpco++;
                }
                else if (exp->cal == 12)
                {
                    // inst.push_back(".L"+to_string(jmpco-1)+":");
                    inst.push_back("    movl    $0, %" + reg[top - 2]);
                    jmpco++;
                    inst.push_back("    jmp .L" + to_string(jmpco));
                    inst.push_back(".L" + to_string(jmpco - 1) + ":");
                    inst.push_back("    movl    $1, %" + reg[top - 2]);
                    inst.push_back(".L" + to_string(jmpco) + ":");
                    jmpco++;
                }
                else
                    inst.push_back("    " + arr[exp->cal] + "  %" + reg[top - 1] + ",%" + reg[top - 2]);
            }
            else
            {
                if (reg[top - 1] != "eax")
                {
                    if (reg[top - 2] != "eax")
                        inst.push_back("    pushl   %eax");
                    inst.push_back("    movl    %" + reg[top - 2] + ", %eax");

                    inst.push_back("    cltd");
                    inst.push_back("    idivl   %" + reg[top - 1]);

                    inst.push_back("    movl    %eax, %" + reg[top - 2]);
                    //inst.push_back("    movl    %" + reg[top-1] + ", %" + reg[top -2]);
                    if (reg[top - 2] != "eax")
                        inst.push_back("    popl   %eax");
                }
                else
                {
                    inst.push_back("    movl    %eax, %" + reg[top]);
                    inst.push_back("    movl    %" + reg[top - 2] + ", %eax");
                    inst.push_back("    cltd");
                    inst.push_back("    idivl   %" + reg[top]);
                    inst.push_back("    movl    %eax, %" + reg[top - 2]);
                }

                /*else
                {
                    inst.push_back("    movl    %" + reg[top - 1] + ", %eax");
                    inst.push_back("    cltd");
                    inst.push_back("    idivl   %" + reg[top]);
                    inst.push_back("    movl    %eax, %" + reg[top - 1]);
                    inst.push_back("    movl    %" + reg[top] + ", %" + reg[top + 2]);
                }*/
            }
            top = top - 1;
        }
        else if (exp->left->label < 6 && (exp->left->label < exp->right->label))
        {
            swap();
            codeg(exp->right);
            if (exp->cal == 11)
            {
                inst.push_back("    cmpl    $0, %" + reg[top - 1]);
                inst.push_back("    je .L" + to_string(jmpco));
                codeg(exp->left);
                inst.push_back("    cmpl    $0, %" + reg[top - 1]);
                // jmpco++;
                inst.push_back("    je .L" + to_string(jmpco));
            }
            else if (exp->cal == 12)
            {
                inst.push_back("    cmpl    $0, %" + reg[top - 1]);
                inst.push_back("    jne .L" + to_string(jmpco));
                codeg(exp->left);
                inst.push_back("    cmpl    $0, %" + reg[top - 1]);
                // jmpco++;
                inst.push_back("    jne .L" + to_string(jmpco));
            }
            else
            {
                codeg(exp->left);
            }
            if (exp->cal != 4)
            {
                if (exp->cal > 4 && exp->cal <= 10)
                {
                    inst.push_back("    cmpl    %" + reg[top - 2] + "(%ebp)," + "%" + reg[top - 1]);
                    inst.push_back("    " + arr[exp->cal] + "   %al");
                    inst.push_back("    movzbl  %al, %" + reg[top - 1]);
                }
                else if (exp->cal == 11)
                {
                    // inst.push_back(".L"+to_string(jmpco-1)+":");
                    inst.push_back("    movl    $1, %" + reg[top - 1]);
                    jmpco++;
                    inst.push_back("    jmp .L" + to_string(jmpco));
                    inst.push_back(".L" + to_string(jmpco - 1) + ":");
                    inst.push_back("    movl    $0, %" + reg[top - 1]);
                    inst.push_back(".L" + to_string(jmpco) + ":");
                    jmpco++;
                }
                else if (exp->cal == 12)
                {
                    // inst.push_back(".L"+to_string(jmpco-1)+":");
                    inst.push_back("    movl    $0, %" + reg[top - 1]);
                    jmpco++;
                    inst.push_back("    jmp .L" + to_string(jmpco));
                    inst.push_back(".L" + to_string(jmpco - 1) + ":");
                    inst.push_back("    movl    $1, %" + reg[top - 1]);
                    inst.push_back(".L" + to_string(jmpco) + ":");
                    jmpco++;
                }
                else
                    inst.push_back("    " + arr[exp->cal] + "  %" + reg[top - 2] + ",%" + reg[top - 1]);
            }
            else
            {
                //cout<<"this case"<<endl;
                if (top != 2)
                    inst.push_back("    pushl   %eax");
                inst.push_back("    movl    %" + reg[top - 1] + ", %eax");
                inst.push_back("    cltd");
                inst.push_back("    idivl   %" + reg[top - 2]);
                inst.push_back("    movl    %eax, %" + reg[top - 1]);
                if (top != 2)
                    inst.push_back("    popl   %eax");
            }
            top = top - 2;
            swap();
            top++;
        }
        else if (exp->right->label == -1)
        {

            string x = to_string(exp->right->off);

            // cout<<x<<endl;
            codeg(exp->left);
            if (exp->right->loc != "")
            {

                string y = arr[exp->cal] + "  ";
                y = y + x;
                y = y + "(%" + exp->right->loc + "),";
                y = y + "%";
                y = y + reg[top - 1];
                if (exp->cal == 11)
                {
                    inst.push_back("    cmpl    $0, %" + reg[top - 1]);
                    inst.push_back("    je .L" + to_string(jmpco));
                    // codeg(exp->right);
                    inst.push_back("    cmpl    $0, " + x + "(%ebp)");
                    // jmpco++;
                    inst.push_back("    je .L" + to_string(jmpco));
                }
                else if (exp->cal == 12)
                {
                    inst.push_back("    cmpl    $0, %" + reg[top - 1]);
                    inst.push_back("    jne .L" + to_string(jmpco));
                    // codeg(exp->right);
                    inst.push_back("    cmpl    $0, " + x + "(%ebp)");
                    // jmpco++;
                    inst.push_back("    jne .L" + to_string(jmpco));
                }
                // cout<<y<<endl;
                if (exp->cal != 4)
                {

                    if (exp->cal > 4 && exp->cal <= 10)
                    {
                        //cout<<"came"<<endl;
                        inst.push_back("    cmpl    " + x + "(%ebp)," + "%" + reg[top - 1]);
                        inst.push_back("    " + arr[exp->cal] + "   %al");
                        inst.push_back("    movzbl  %al, %" + reg[top - 1]);
                        //cout<<"cameout"<<endl;
                    }
                    else if (exp->cal == 11)
                    {
                        // inst.push_back(".L"+to_string(jmpco-1)+":");
                        inst.push_back("    movl    $1, %" + reg[top - 1]);
                        jmpco++;
                        inst.push_back("    jmp .L" + to_string(jmpco));
                        inst.push_back(".L" + to_string(jmpco - 1) + ":");
                        inst.push_back("    movl    $0, %" + reg[top - 1]);
                        inst.push_back(".L" + to_string(jmpco) + ":");
                        jmpco++;
                    }
                    else if (exp->cal == 12)
                    {
                        // inst.push_back(".L"+to_string(jmpco-1)+":");
                        inst.push_back("    movl    $0, %" + reg[top - 1]);
                        jmpco++;
                        inst.push_back("    jmp .L" + to_string(jmpco));
                        inst.push_back(".L" + to_string(jmpco - 1) + ":");
                        inst.push_back("    movl    $1, %" + reg[top - 1]);
                        inst.push_back(".L" + to_string(jmpco) + ":");
                        jmpco++;
                    }
                    else if (exp->cal == 14)
                    {
                        inst.push_back("    movl    " + x + "(%" + exp->right->loc + ")" + ", " + "%" + reg[top]);
                        if (exp->off != 0)
                            inst.push_back("    movl    %" + reg[top] + ", " + to_string(exp->off) + "(%" + reg[top - 1] + ")");
                        else
                            inst.push_back("    movl    %" + reg[top] + ", " + "(%" + reg[top - 1] + ")");
                    }
                    else
                        inst.push_back("    " + y);
                }
                else
                {
                    if (top > 1)
                    {
                        inst.push_back("    pushl   %eax");
                        // inst.push_back("    pushl   %" + reg[top + 1]);
                        inst.push_back("    movl    %" + reg[top - 1] + ", %eax");
                        inst.push_back("    movl    " + x + "(%ebp)" + ", %" + reg[top - 1]);
                        inst.push_back("    cltd");
                        inst.push_back("    idivl   %" + reg[top - 1]);
                        inst.push_back("    movl    %eax, %" + reg[top - 1]);
                        // inst.push_back("    popl   %" + reg[top + 1]);
                        inst.push_back("    popl   %eax");
                    }
                    else
                    {
                        //inst.push_back("    movl    %" + reg[top] + ", %eax");
                        inst.push_back("    movl    " + x + "(%ebp)" + ", %" + reg[top]);
                        inst.push_back("    cltd");
                        inst.push_back("    idivl   %" + reg[top]);
                    }
                    // inst.push_back("    movl    %" + reg[top] + ", %eax");
                    // inst.push_back("    cltd");
                    // inst.push_back("    idivl   %" + x + "(%ebp)");
                    // inst.push_back("    movl    %eax, %" + reg[top]);
                }
                //cout<<"cameouttt"<<endl;
            }
            else
            {
                string y = arr[exp->cal] + "  $";
                y = y + x;
                y = y + ",";
                y = y + "%";
                y = y + reg[top];
                // cout<<y<<endl;
                if (exp->cal == 11)
                {

                    inst.push_back("    cmpl    $0, %" + reg[top - 1]);
                    inst.push_back("    je .L" + to_string(jmpco));
                    // codeg(exp->right);
                    inst.push_back("    movl   $" + x + ", %" + reg[top - 1]);
                    inst.push_back("    cmpl    $0, %" + reg[top - 1]);
                    // jmpco++;
                    inst.push_back("    je .L" + to_string(jmpco));
                }
                if (exp->cal == 12)
                {
                    inst.push_back("    cmpl    $0, %" + reg[top - 1]);
                    inst.push_back("    jne .L" + to_string(jmpco));
                    // codeg(exp->right);
                    inst.push_back("    movl   $" + x + ", %" + reg[top - 1]);

                    inst.push_back("    cmpl    $0, %" + reg[top - 1]);
                    // jmpco++;
                    inst.push_back("    jne .L" + to_string(jmpco));
                }
                if (exp->cal != 4)
                {
                    if (exp->cal > 4 && exp->cal <= 10)
                    {
                        // cout<<"went"<<endl;
                        inst.push_back("    cmpl    $" + x + ",%" + reg[top - 1]);
                        inst.push_back("    " + arr[exp->cal] + "   %al");
                        inst.push_back("    movzbl  %al, %" + reg[top - 1]);
                        // cout<<"went out"<<endl;
                    }
                    else if (exp->cal == 11)
                    {
                        // inst.push_back(".L"+to_string(jmpco-1)+":");
                        inst.push_back("    movl    $1, %" + reg[top - 1]);
                        jmpco++;
                        inst.push_back("    jmp .L" + to_string(jmpco));
                        inst.push_back(".L" + to_string(jmpco - 1) + ":");
                        inst.push_back("    movl    $0, %" + reg[top - 1]);
                        inst.push_back(".L" + to_string(jmpco) + ":");
                        jmpco++;
                    }
                    else if (exp->cal == 12)
                    {
                        // inst.push_back(".L"+to_string(jmpco-1)+":");
                        inst.push_back("    movl    $0, %" + reg[top - 1]);
                        jmpco++;
                        inst.push_back("    jmp .L" + to_string(jmpco));
                        inst.push_back(".L" + to_string(jmpco - 1) + ":");
                        inst.push_back("    movl    $1, %" + reg[top - 1]);
                        inst.push_back(".L" + to_string(jmpco) + ":");
                        jmpco++;
                    }
                    else if (exp->cal == 14)
                    {

                        if (exp->off != 0)
                            inst.push_back("    movl    $" + to_string(exp->right->off) + ", " + to_string(exp->off) + "(%" + reg[top - 1] + ")");
                        else
                            inst.push_back("    movl    $" + to_string(exp->right->off) + ", " + "(%" + reg[top - 1] + ")");
                    }
                    else
                        inst.push_back("    " + arr[exp->cal] + "  $" + to_string(exp->right->off) + ", %" + reg[top - 1]);
                }
                else
                {
                    if (top > 1)
                    {
                        inst.push_back("    pushl   %eax");
                        // inst.push_back("    pushl   %" + reg[top + 1]);
                        inst.push_back("    movl    %" + reg[top - 1] + ", %eax");
                        inst.push_back("    movl    $" + to_string(exp->right->off) + ", %" + reg[top - 1]);

                        inst.push_back("    cltd");
                        inst.push_back("    idivl   %" + reg[top - 1]);

                        inst.push_back("    movl    %eax, %" + reg[top - 1]);
                        // inst.push_back("    popl   %" + reg[top + 1]);
                        inst.push_back("    popl   %eax");
                    }
                    else
                    {
                        //inst.push_back("    movl    %" + reg[top] + ", %eax");
                        inst.push_back("    movl    $" + to_string(exp->right->off) + ", %" + reg[top]);
                        inst.push_back("    cltd");
                        inst.push_back("    idivl   %" + reg[top]);
                    }
                }
            }
        }
    }
}
}
