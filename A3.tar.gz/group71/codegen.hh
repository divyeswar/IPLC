#include <string>
#include <vector>
#include <iostream>
#include <map>
#include <utility>
#include <cstdlib>
#include "type.hh"
 #include "ast.hh"
using std::vector;
using std::string;
string to_str(int a);
void swap();
void codeg(exp_astnode* exp);