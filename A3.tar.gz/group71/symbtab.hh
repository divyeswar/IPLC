#ifndef SYMTAB_HH
#define SYMTAB_HH
#include <string>
#include <map>
#include <vector>
using namespace std;
class SymbTab;
struct symbol_t{
    string name;
    string varfun;
    string dtype;
    int size;
    int offset;
    string scope;
    SymbTab* symbtab;

};
class SymbTab{
    public:
        void add_symbol(symbol_t* symb);
        // symbol_t get_symbol(const string& name,int scope);
        // bool symbol_exits(const string& name,int scope);
        void print();
        void printgst();
        // int get_next_offset(int scope);
        // void create_scope();
        // vois destroy_scope();
    // private:
        map<string,symbol_t*> Entries;
        vector<string> order;
        int paramcount;
        vector<string> param;

        // vector<unordered_map<string,symbol_t>> local_table;
        // int current_scope=0;
};
#endif