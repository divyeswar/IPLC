#ifndef TYPE_HH
#define TYPE_HH
#include <string>
#include <vector>
using namespace std;
class typecheck{
    public:
    string datatype;
    string sname;
    bool iszero;
    int countstars;
    int countbraces;
    vector<string> val;
    int lval;
    typecheck(){
        this->countbraces=0;
        this->countstars=0;
        this->lval=0;
        this->iszero=0;
    }
    void insertval(string a);
    string conc();

};
#endif
